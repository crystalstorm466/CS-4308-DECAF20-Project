The following is a list of files in this archive:
main.py - The main source code for the Scanner coded in python3
scanner_t1_out.txt - Sample output of t1.decaf (Provided by Instructor)
scanner_t3_out.txt - Sample output of t3.decaf (Provided by Instructor)
scanner_t4_out.txt - Sample output of t3.decaf (Provided by Instructor)
t1.out - Output of main.py with t1.decaf (Provided by Me) - ASCII text file
t3.out - Output of main.py with t3.decaf (Provided by Me) - ASCII text file
t4.out - Output of main.py with t4.decaf (Provided by Me) - ASCII text file
Samples/t1.decaf - Sample input 1 (Provided by Instructor)
Samples/t3.decaf - Sample input 3 (Provided by Instructor)
Samples/t4.decaf - Sample input	4 (Provided by Instructor)

Usage (do not use < > in arguments):
python3 main.py <file name>
