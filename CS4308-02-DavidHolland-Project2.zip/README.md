The following is a list of files in this archive:

scanner.py - The main source code for the Scanner coded in python3

parser.py -  The main source code for the Parser coder in python3

scanner/scanner_t1_out.txt - Sample output of t1.decaf (Provided by Instructor)

scanner/scanner_t3_out.txt - Sample output of t3.decaf (Provided by Instructor)

scanner/scanner_t4_out.txt - Sample output of t3.decaf (Provided by Instructor)

scanner/t1.out - Output of main.py with t1.decaf (Provided by Me) - ASCII text file

scanner/t3.out - Output of main.py with t3.decaf (Provided by Me) - ASCII text file

scanner/t4.out - Output of main.py with t4.decaf (Provided by Me) - ASCII text file

Samples/t1.decaf - Sample input 1 (Provided by Instructor)

Samples/t3.decaf - Sample input 3 (Provided by Instructor)

Samples/t4.decaf - Sample input	4 (Provided by Instructor)

Samples/bad1.decaf -  Sample input 1 (Provided by Instructor)

Samples/bad3.decaf -  Sample input 3 (Provided by Instructor)

Samples/bad4.decaf -  Sample input 4 (Provided by Instructor)

Samples/bad6.decaf -  Sample input 6 (Provided by Instructor)

Samples/bad1.out -  Sample output of bad1.decaf (Provided by Instructor)

Samples/bad3.out -  Sample output of bad3.dcaf (Provided by Instructor)

Samples/bad4.out -  Sample output of bad3.deaf (Provided by Instructor)

Samples/bad6.out -  Sample output of bad5.decaf (Provided by Instructor)



Usage (do not use < > in arguments):
Scanner: python3 scanner.py <file name>
Parser:  python3 parser.py <file name>
